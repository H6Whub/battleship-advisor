# Battleship Advisor

Chrome extension for battleship-game.org. Shows the optimal cell to shoot each turn.
Supports RU (10 ships) and Classic (5 ships) — auto-detected.

## Install

1. Unzip → folder
2. Chrome → `chrome://extensions`
3. Enable **Developer mode**
4. **Load unpacked** → select folder
5. Open battleship-game.org

## Controls

- **PIN** — lock panel
- **FIND** — toggle outline on enemy field
- Backtick or Esc — hide panel
- Drag header — move panel

## Remove ads

Open `advisor.js`, find the line with `// AD` and delete the `setTimeout(sendChat,1500)` call on that line.

## Support

https://ko-fi.com/maixyyy
